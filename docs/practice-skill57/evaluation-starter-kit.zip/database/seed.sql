-- [ไฟล์ร่วม] ข้อมูลตัวอย่าง — รหัสผ่านทุกบัญชีคือ 1234
SET NAMES utf8mb4;
-- รันซ้ำได้: ล้างข้อมูลเก่าก่อนใส่ใหม่ หัวข้อเปิดอยู่เสมอ (นับจากวันที่รัน)
USE evaluation_db;
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE committee_scores; TRUNCATE evidences; TRUNCATE self_scores;
TRUNCATE assignments; TRUNCATE indicators; TRUNCATE topics; TRUNCATE users;
SET FOREIGN_KEY_CHECKS = 1;

-- id 1 admin | 2-3 ผู้รับการประเมิน | 4-5 กรรมการ
INSERT INTO users (id, username, password_hash, full_name, email, position, role, must_change_password) VALUES
(1, 'admin', 'a1b2c3d4e5f60718:94426f001efc0c971a12f13590d4b9ac0a9d97d435ca27758453dc341d17e833', 'งานบุคลากร วท.เลย', 'hr@ltc.ac.th', 'เจ้าหน้าที่งานบุคลากร', 'admin', 0),
(2, 'eva1', 'a1b2c3d4e5f60718:94426f001efc0c971a12f13590d4b9ac0a9d97d435ca27758453dc341d17e833', 'สมชาย ใจดี', 'somchai@ltc.ac.th', 'ครู', 'evaluatee', 0),
(3, 'eva2', 'a1b2c3d4e5f60718:94426f001efc0c971a12f13590d4b9ac0a9d97d435ca27758453dc341d17e833', 'สมหญิง รักเรียน', 'somying@ltc.ac.th', 'ครูผู้ช่วย', 'evaluatee', 1),
(4, 'com1', 'a1b2c3d4e5f60718:94426f001efc0c971a12f13590d4b9ac0a9d97d435ca27758453dc341d17e833', 'ประธาน ประเมินดี', 'chair@ltc.ac.th', 'รองผู้อำนวยการ', 'committee', 0),
(5, 'com2', 'a1b2c3d4e5f60718:94426f001efc0c971a12f13590d4b9ac0a9d97d435ca27758453dc341d17e833', 'กรรมการ ร่วมใจ', 'member@ltc.ac.th', 'หัวหน้าแผนก', 'committee', 1);

INSERT INTO topics (id, title, description, start_date, end_date) VALUES
(1, 'ประเมินผลการปฏิบัติงาน ภาคเรียนที่ 2/2569', 'ตัวอย่างหัวข้อสำหรับซ้อม',
 CURDATE() - INTERVAL 7 DAY, CURDATE() + INTERVAL 30 DAY);

INSERT INTO indicators (id, topic_id, name, detail, weight, eval_type, evidence_note) VALUES
(1, 1, 'การจัดการเรียนการสอน', 'มีแผนการสอนและสื่อครบทุกรายวิชา', 30, 'scale_4', 'แผนการสอน (PDF)'),
(2, 1, 'การพัฒนาตนเอง', 'เข้าอบรมอย่างน้อย 20 ชั่วโมงต่อปี', 30, 'scale_4', 'เกียรติบัตร'),
(3, 1, 'มีรายงานการวิจัยในชั้นเรียน', 'ส่งรายงานภายในภาคเรียน', 20, 'yes_no', 'ไฟล์รายงาน'),
(4, 1, 'เข้าร่วมกิจกรรมวิทยาลัย', 'เข้าร่วมกิจกรรมหลักของวิทยาลัย', 20, 'yes_no', 'ภาพถ่ายหรือ URL');

INSERT INTO assignments (id, topic_id, evaluatee_id, committee_id, committee_role, status, overall_comment) VALUES
(1, 1, 2, 4, 'chair', 'pending', NULL),
(2, 1, 2, 5, 'member', 'draft', 'ผลงานดี ควรเพิ่มหลักฐานการอบรม'),
(3, 1, 3, 4, 'chair', 'pending', NULL);

INSERT INTO self_scores (evaluatee_id, indicator_id, score) VALUES
(2, 1, 4), (2, 2, 3), (2, 3, 1);

INSERT INTO evidences (evaluatee_id, indicator_id, detail, file_path, url) VALUES
(2, 1, 'แผนการสอนวิชาการเขียนโปรแกรม', NULL, 'https://example.com/plan.pdf'),
(2, 1, 'สื่อการสอนออนไลน์', NULL, 'https://example.com/course'),
(2, 2, 'อบรม Node.js 12 ชั่วโมง', NULL, NULL);

INSERT INTO committee_scores (assignment_id, indicator_id, score) VALUES
(2, 1, 4), (2, 2, 2);
