-- [ไฟล์ร่วม] สร้างฐานข้อมูลระบบประเมินบุคลากร 7 ตาราง
SET NAMES utf8mb4;
-- รันทั้งไฟล์ใน HeidiSQL / DBeaver / phpMyAdmin แล้วรัน seed.sql ต่อ
DROP DATABASE IF EXISTS evaluation_db;
CREATE DATABASE evaluation_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE evaluation_db;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(200) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  phone VARCHAR(20),
  position VARCHAR(100),
  role ENUM('admin', 'evaluatee', 'committee') NOT NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE topics (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE indicators (
  id INT AUTO_INCREMENT PRIMARY KEY,
  topic_id INT NOT NULL,
  name VARCHAR(200) NOT NULL,
  detail TEXT,
  weight DECIMAL(5,2) NOT NULL DEFAULT 1,
  eval_type ENUM('yes_no', 'scale_4') NOT NULL DEFAULT 'scale_4',
  evidence_note VARCHAR(255),
  FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

CREATE TABLE assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  topic_id INT NOT NULL,
  evaluatee_id INT NOT NULL,
  committee_id INT NOT NULL,
  committee_role ENUM('chair', 'member') NOT NULL DEFAULT 'member',
  status ENUM('pending', 'draft', 'confirmed') NOT NULL DEFAULT 'pending',
  overall_comment TEXT,
  signature_path VARCHAR(255),
  confirmed_at DATETIME,
  UNIQUE KEY uq_assignment (topic_id, evaluatee_id, committee_id),
  FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE,
  FOREIGN KEY (evaluatee_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (committee_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE self_scores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  evaluatee_id INT NOT NULL,
  indicator_id INT NOT NULL,
  score TINYINT NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_self (evaluatee_id, indicator_id),
  FOREIGN KEY (evaluatee_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (indicator_id) REFERENCES indicators(id) ON DELETE CASCADE
);

CREATE TABLE evidences (
  id INT AUTO_INCREMENT PRIMARY KEY,
  evaluatee_id INT NOT NULL,
  indicator_id INT NOT NULL,
  detail TEXT NOT NULL,
  file_path VARCHAR(255),
  url VARCHAR(500),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (evaluatee_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (indicator_id) REFERENCES indicators(id) ON DELETE CASCADE
);

CREATE TABLE committee_scores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  assignment_id INT NOT NULL,
  indicator_id INT NOT NULL,
  score TINYINT NOT NULL,
  UNIQUE KEY uq_committee_score (assignment_id, indicator_id),
  FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
  FOREIGN KEY (indicator_id) REFERENCES indicators(id) ON DELETE CASCADE
);
