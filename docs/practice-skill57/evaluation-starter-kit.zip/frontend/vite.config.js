import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: { host: true, port: 5173 }, // host: true = เครื่องอื่นในวงแลนเปิดดูได้
})
