<!-- [คนที่ 1 — งานบุคลากร] รายงานผลการประเมิน -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// A10  GET /reports/progress?topic_id=  -> ตารางร้อยละการบันทึกของแต่ละคน
// A11/A12  เลือกผู้รับการประเมิน -> GET /reports/evaluatees/:id?topic_id=
//          ตารางตัวชี้วัด x (คะแนนตนเอง, คะแนนกรรมการแต่ละคน) + ร้อยละรวม + ความคิดเห็น  ปุ่มพิมพ์ = window.print()
</script>

<template>
  <h2>รายงานผลการประเมิน</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
