<!-- [คนที่ 1 — งานบุคลากร] หัวข้อการประเมิน -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// A4  GET /topics -> ตาราง: ชื่อหัวข้อ, วันเริ่ม-สิ้นสุด, สถานะ (is_open = 1 -> เปิดอยู่)
//     ฟอร์มเพิ่ม/แก้ (title, description, start_date, end_date) วันเริ่มต้องไม่เกินวันสิ้นสุด
//     ปุ่ม "ตัวชี้วัด" -> router.push(`/admin/topics/${id}/indicators`)
</script>

<template>
  <h2>หัวข้อการประเมิน</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
