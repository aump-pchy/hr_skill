<!-- [คนที่ 1 — งานบุคลากร] Dashboard -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// A13  GET /reports/dashboard -> แสดงการ์ดตัวเลข: ผู้รับการประเมิน, กรรมการ, ยืนยันแล้ว/ทั้งหมด, ค่าเฉลี่ยร้อยละ
</script>

<template>
  <h2>Dashboard</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
