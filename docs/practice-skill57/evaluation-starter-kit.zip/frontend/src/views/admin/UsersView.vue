<!-- [คนที่ 1 — งานบุคลากร] จัดการผู้รับการประเมิน / กรรมการ (A1 A2 A3) -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const role = ref('evaluatee') // สลับดู evaluatee / committee
const rows = ref([])
const error = ref('')

// ตัวอย่างรูปแบบมาตรฐาน: โหลดข้อมูล
async function load() {
  error.value = ''
  try {
    const res = await api.get('/users', { params: { role: role.value } })
    rows.value = res.data.data
  } catch (err) {
    error.value = errorMessage(err)
  }
}
onMounted(load)

// TODO A1/A2  ฟอร์มเพิ่ม/แก้ (username, full_name, email, phone, position) -> POST / PUT /users
// TODO A1/A2  ปุ่มลบ (confirm ก่อน) -> DELETE /users/:id
// TODO A3     ปุ่ม "รีเซ็ตรหัส" -> PUT /users/:id/reset-password
</script>

<template>
  <h2>จัดการผู้ใช้</h2>
  <select v-model="role" @change="load">
    <option value="evaluatee">ผู้รับการประเมิน</option>
    <option value="committee">กรรมการ</option>
  </select>
  <p v-if="error" class="error">{{ error }}</p>
  <div class="table-wrap">
    <table>
      <thead><tr><th>ชื่อผู้ใช้</th><th>ชื่อ-สกุล</th><th>ตำแหน่ง</th><th>อีเมล</th><th></th></tr></thead>
      <tbody>
        <tr v-for="u in rows" :key="u.id">
          <td>{{ u.username }}</td><td>{{ u.full_name }}</td><td>{{ u.position }}</td><td>{{ u.email }}</td>
          <td><!-- ปุ่ม แก้ / ลบ / รีเซ็ตรหัส --></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
