<!-- [คนที่ 1 — งานบุคลากร] มอบหมายกรรมการ -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// A7/A8/A9  เลือกหัวข้อ -> GET /assignments?topic_id=  ตาราง: ผู้รับการประเมิน, กรรมการ, บทบาท, สถานะ
//           ฟอร์ม: select ผู้รับการประเมิน (GET /users?role=evaluatee), select กรรมการ, select บทบาท (chair/member)
//           สถานะแสดงเป็นคำไทย: pending = ยังไม่ประเมิน, draft = บันทึกร่าง, confirmed = ยืนยันแล้ว
</script>

<template>
  <h2>มอบหมายกรรมการ</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
