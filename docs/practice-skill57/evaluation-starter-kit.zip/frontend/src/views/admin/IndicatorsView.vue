<!-- [คนที่ 1 — งานบุคลากร] ตัวชี้วัด -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// A5/A6  topicId = useRoute().params.id   GET /indicators?topic_id=
//        ฟอร์ม: name, detail, weight, evidence_note, eval_type (select: มี/ไม่มี = yes_no, สเกล 1-4 = scale_4)
//        เมื่อเลือก scale_4 ให้แสดงคำอธิบายระดับ 1-4 ตามเกณฑ์ 5.1.4
</script>

<template>
  <h2>ตัวชี้วัด</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
