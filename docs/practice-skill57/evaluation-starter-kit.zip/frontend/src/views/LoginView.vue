<!-- [ไฟล์ร่วม] หน้า Login ใช้ได้ทุกบทบาท -->
<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import api, { errorMessage } from '../api'
import { saveLogin, homePath } from '../auth'

const router = useRouter()
const username = ref('')
const password = ref('')
const error = ref('')
const loading = ref(false)

async function login() {
  error.value = ''
  if (!username.value || !password.value) {
    error.value = 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน'
    return
  }
  loading.value = true
  try {
    const res = await api.post('/auth/login', { username: username.value, password: password.value })
    const { token, user } = res.data.data
    saveLogin(token, user)
    router.push(user.must_change_password ? '/change-password' : homePath(user.role))
  } catch (err) {
    error.value = errorMessage(err)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="login">
    <h1>ระบบประเมินบุคลากร</h1>
    <form @submit.prevent="login">
      <label>ชื่อผู้ใช้ <input v-model.trim="username" autocomplete="username" /></label>
      <label>รหัสผ่าน <input v-model="password" type="password" autocomplete="current-password" /></label>
      <p v-if="error" class="error">{{ error }}</p>
      <button :disabled="loading">{{ loading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ' }}</button>
    </form>
  </div>
</template>

<style scoped>
.login { max-width: 360px; margin: 64px auto; }
form { display: grid; gap: 12px; }
label { display: grid; gap: 4px; }
</style>
