<!-- [คนที่ 3 — ใช้ร่วมทุกบทบาท] เปลี่ยนรหัสผ่าน -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../api'

const error = ref('')

// TODO:
// E1  ฟอร์ม: รหัสเดิม, รหัสใหม่, ยืนยันรหัสใหม่ (ตรวจว่าตรงกัน + ยาว >= 6 ก่อนส่ง)
//     PUT /auth/change-password -> สำเร็จ: updateUser({ must_change_password: 0 }) แล้ว router.push(homePath(role))
//     import { getUser, updateUser, homePath } from '../auth'
</script>

<template>
  <h2>เปลี่ยนรหัสผ่าน</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
