<!-- [คนที่ 2 — กรรมการ] รายชื่อผู้รับการประเมินที่ต้องประเมิน (C1) -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const rows = ref([])
const error = ref('')
const statusText = { pending: 'ยังไม่ประเมิน', draft: 'บันทึกร่าง', confirmed: 'ยืนยันแล้ว' }

onMounted(async () => {
  try {
    const res = await api.get('/committee/assignments')
    rows.value = res.data.data
  } catch (err) {
    error.value = errorMessage(err)
  }
})
</script>

<template>
  <h2>ผู้รับการประเมินที่ต้องประเมิน</h2>
  <p v-if="error" class="error">{{ error }}</p>
  <div class="table-wrap">
    <table>
      <thead><tr><th>ชื่อ-สกุล</th><th>ตำแหน่ง</th><th>บทบาทของฉัน</th><th>สถานะ</th><th></th></tr></thead>
      <tbody>
        <tr v-for="a in rows" :key="a.id">
          <td>{{ a.evaluatee_name }}</td>
          <td>{{ a.position }}</td>
          <td>{{ a.committee_role === 'chair' ? 'ประธาน' : 'กรรมการร่วม' }}</td>
          <td>{{ statusText[a.status] }}</td>
          <td>
            <RouterLink :to="`/committee/${a.id}`">ประเมิน</RouterLink> |
            <RouterLink :to="`/committee/${a.id}/result`">ดูผล</RouterLink>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
