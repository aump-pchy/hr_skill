<!-- [คนที่ 2 — กรรมการ] ประเมิน -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// C2  id = useRoute().params.id   GET /committee/assignments/:id
//     แต่ละตัวชี้วัด: ชื่อ, รายละเอียด, น้ำหนัก, คะแนนตนเอง, รายการหลักฐาน (ลิงก์ fileUrl / url)
// C3  ช่องให้คะแนน: yes_no = radio มี/ไม่มี, scale_4 = select 1-4
// C4  textarea ความคิดเห็นสรุป
// C5  ปุ่ม "บันทึกร่าง" -> PUT /committee/assignments/:id/scores
// C7  input type=file ลายเซ็น -> FormData -> POST /committee/assignments/:id/signature
// C8  ปุ่ม "ยืนยันส่งผล" (confirm ก่อน) -> PUT /committee/assignments/:id/confirm
//     status = confirmed -> ปิดทุกช่อง (disabled)
</script>

<template>
  <h2>ประเมิน</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
