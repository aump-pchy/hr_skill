<!-- [คนที่ 2 — กรรมการ] ผลการประเมิน -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// C6  GET /committee/assignments/:id -> ตาราง: ตัวชี้วัด, น้ำหนัก, คะแนนตนเอง, คะแนนที่ให้, คะแนนถ่วง
//     แถวสรุป: total_percent + ความคิดเห็น + รูปลายเซ็น <img :src="fileUrl(signature_path)">
</script>

<template>
  <h2>ผลการประเมิน</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
