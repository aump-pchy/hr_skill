<!-- [คนที่ 3 — ผู้รับการประเมิน] แบบรายงานการประเมินตนเอง -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// E8  GET /evaluatee/indicators -> จัดหน้าแบบเอกสาร: ข้อมูลผู้รับการประเมิน + ตารางตัวชี้วัด/คะแนน/หลักฐาน
//     ปุ่ม class="no-print" เรียก window.print() แล้วเลือก "บันทึกเป็น PDF" (ไม่ต้องลง library เพิ่ม)
</script>

<template>
  <h2>แบบรายงานการประเมินตนเอง</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
