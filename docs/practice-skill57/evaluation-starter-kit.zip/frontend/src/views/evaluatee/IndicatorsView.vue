<!-- [คนที่ 3 — ผู้รับการประเมิน] ตัวชี้วัดของฉัน -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// E3  GET /evaluatee/indicators -> การ์ดต่อ 1 ตัวชี้วัด (ชื่อ, รายละเอียด, น้ำหนัก, หลักฐานที่ต้องแนบ)
// E6  ช่องคะแนนตนเอง (yes_no = มี/ไม่มี, scale_4 = 1-4) + ปุ่มบันทึก -> PUT /evaluatee/self-scores/:indicatorId
// E4/E5  ฟอร์มเพิ่มรายการ: detail (บังคับ), url, file -> FormData -> POST /evaluatee/evidences
//        รายการที่มีแล้ว + ปุ่มลบ -> DELETE /evaluatee/evidences/:id
// E7  ความก้าวหน้า: ต่อตัวชี้วัดแสดง มีรายละเอียด? มีหลักฐาน? มีคะแนน?  + ร้อยละรวมด้านบน
// E8  ปุ่ม "Export PDF" -> router.push('/evaluatee/print')
</script>

<template>
  <h2>ตัวชี้วัดของฉัน</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
