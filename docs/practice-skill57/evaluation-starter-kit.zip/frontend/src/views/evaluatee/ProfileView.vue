<!-- [คนที่ 3 — ผู้รับการประเมิน] แก้ไขข้อมูลส่วนตัว (E2) -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'
import { updateUser } from '../../auth'

const form = ref({ full_name: '', email: '', phone: '', position: '' })
const error = ref('')
const message = ref('')

onMounted(async () => {
  const res = await api.get('/auth/me')
  form.value = res.data.data
})

// TODO E2  ตรวจก่อนส่ง: full_name ห้ามว่าง, email ต้องมีรูปแบบ x@y.z
async function save() {
  error.value = ''
  message.value = ''
  try {
    const res = await api.put('/evaluatee/profile', form.value)
    updateUser({ full_name: form.value.full_name })
    message.value = res.data.message
  } catch (err) {
    error.value = errorMessage(err)
  }
}
</script>

<template>
  <h2>ข้อมูลส่วนตัว</h2>
  <form @submit.prevent="save" class="form">
    <label>ชื่อ-สกุล <input v-model.trim="form.full_name" /></label>
    <label>อีเมล <input v-model.trim="form.email" /></label>
    <label>โทรศัพท์ <input v-model.trim="form.phone" /></label>
    <label>ตำแหน่ง <input v-model.trim="form.position" /></label>
    <p v-if="error" class="error">{{ error }}</p>
    <p v-if="message" class="success">{{ message }}</p>
    <button>บันทึก</button>
  </form>
</template>

<style scoped>
.form { display: grid; gap: 10px; max-width: 420px; }
label { display: grid; gap: 4px; }
</style>
