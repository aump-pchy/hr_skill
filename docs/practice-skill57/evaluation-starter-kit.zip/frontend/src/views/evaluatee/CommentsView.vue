<!-- [คนที่ 3 — ผู้รับการประเมิน] ความคิดเห็นของกรรมการ -->
<script setup>
import { ref, onMounted } from 'vue'
import api, { errorMessage } from '../../api'

const error = ref('')

// TODO:
// E9  GET /evaluatee/comments -> การ์ดต่อกรรมการ 1 คน: ชื่อ, ประธาน/กรรมการร่วม, สถานะ, ความคิดเห็น
</script>

<template>
  <h2>ความคิดเห็นของกรรมการ</h2>
  <p v-if="error" class="error">{{ error }}</p>
</template>
