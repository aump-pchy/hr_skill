<!-- [ไฟล์ร่วม] เมนูด้านบนเปลี่ยนตามบทบาท -->
<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getUser, logout } from './auth'

const route = useRoute()
const router = useRouter()
const user = computed(() => (route.path, getUser())) // อ่านใหม่ทุกครั้งที่เปลี่ยนหน้า

function signOut() {
  logout()
  router.push('/login')
}
</script>

<template>
  <nav v-if="user && route.path !== '/login'" class="topbar">
    <template v-if="user.role === 'admin'">
      <RouterLink to="/admin">Dashboard</RouterLink>
      <RouterLink to="/admin/users">ผู้ใช้</RouterLink>
      <RouterLink to="/admin/topics">หัวข้อ/ตัวชี้วัด</RouterLink>
      <RouterLink to="/admin/assignments">มอบหมายกรรมการ</RouterLink>
      <RouterLink to="/admin/reports">รายงาน</RouterLink>
    </template>
    <template v-if="user.role === 'committee'">
      <RouterLink to="/committee">รายชื่อที่ต้องประเมิน</RouterLink>
    </template>
    <template v-if="user.role === 'evaluatee'">
      <RouterLink to="/evaluatee">ตัวชี้วัดของฉัน</RouterLink>
      <RouterLink to="/evaluatee/comments">ความคิดเห็นกรรมการ</RouterLink>
      <RouterLink to="/evaluatee/profile">ข้อมูลส่วนตัว</RouterLink>
    </template>
    <span class="who">{{ user.full_name }}</span>
    <button @click="signOut">ออกจากระบบ</button>
  </nav>
  <main><RouterView /></main>
</template>

<style scoped>
.topbar { display: flex; flex-wrap: wrap; gap: 12px; align-items: center; padding: 10px 16px; border-bottom: 1px solid #d1d5db; }
.who { margin-left: auto; color: #6b7280; }
</style>
