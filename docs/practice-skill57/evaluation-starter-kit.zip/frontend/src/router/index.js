// [ไฟล์ร่วม] ทุกหน้าลงทะเบียนไว้ครบแล้ว ไม่ต้องแก้ไฟล์นี้
// meta.role = บทบาทที่เข้าหน้านี้ได้
import { createRouter, createWebHistory } from 'vue-router'
import { getToken, getUser, homePath } from '../auth'

const routes = [
  { path: '/login', component: () => import('../views/LoginView.vue'), meta: { public: true } },
  { path: '/change-password', component: () => import('../views/ChangePasswordView.vue') },
  { path: '/', redirect: () => homePath(getUser()?.role) },

  // ---- คนที่ 1: งานบุคลากร ----
  { path: '/admin', component: () => import('../views/admin/DashboardView.vue'), meta: { role: 'admin' } },
  { path: '/admin/users', component: () => import('../views/admin/UsersView.vue'), meta: { role: 'admin' } },
  { path: '/admin/topics', component: () => import('../views/admin/TopicsView.vue'), meta: { role: 'admin' } },
  { path: '/admin/topics/:id/indicators', component: () => import('../views/admin/IndicatorsView.vue'), meta: { role: 'admin' } },
  { path: '/admin/assignments', component: () => import('../views/admin/AssignmentsView.vue'), meta: { role: 'admin' } },
  { path: '/admin/reports', component: () => import('../views/admin/ReportsView.vue'), meta: { role: 'admin' } },

  // ---- คนที่ 2: กรรมการ ----
  { path: '/committee', component: () => import('../views/committee/ListView.vue'), meta: { role: 'committee' } },
  { path: '/committee/:id', component: () => import('../views/committee/EvaluateView.vue'), meta: { role: 'committee' } },
  { path: '/committee/:id/result', component: () => import('../views/committee/ResultView.vue'), meta: { role: 'committee' } },

  // ---- คนที่ 3: ผู้รับการประเมิน ----
  { path: '/evaluatee', component: () => import('../views/evaluatee/IndicatorsView.vue'), meta: { role: 'evaluatee' } },
  { path: '/evaluatee/profile', component: () => import('../views/evaluatee/ProfileView.vue'), meta: { role: 'evaluatee' } },
  { path: '/evaluatee/comments', component: () => import('../views/evaluatee/CommentsView.vue'), meta: { role: 'evaluatee' } },
  { path: '/evaluatee/print', component: () => import('../views/evaluatee/PrintView.vue'), meta: { role: 'evaluatee' } },

  { path: '/:pathMatch(.*)*', redirect: '/' },
]

const router = createRouter({ history: createWebHistory(), routes })

// ด่านตรวจทุกครั้งที่เปลี่ยนหน้า
router.beforeEach((to) => {
  if (to.meta.public) return true
  const user = getUser()
  if (!user || !getToken()) return '/login'
  if (user.must_change_password && to.path !== '/change-password') return '/change-password' // บังคับเปลี่ยนรหัส (5.2.1)
  if (to.meta.role && to.meta.role !== user.role) return homePath(user.role)
  return true
})

export default router
