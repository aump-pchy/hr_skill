// [ไฟล์ร่วม] เก็บ token และข้อมูลผู้ใช้ที่ login แล้ว
export function saveLogin(token, user) {
  localStorage.setItem('token', token)
  localStorage.setItem('user', JSON.stringify(user))
}

export function getToken() {
  return localStorage.getItem('token')
}

export function getUser() {
  const text = localStorage.getItem('user')
  return text ? JSON.parse(text) : null
}

// แก้ข้อมูลผู้ใช้ที่เก็บไว้บางส่วน เช่น หลังเปลี่ยนรหัสผ่าน: updateUser({ must_change_password: 0 })
export function updateUser(changes) {
  const user = getUser()
  if (user) localStorage.setItem('user', JSON.stringify({ ...user, ...changes }))
}

export function logout() {
  localStorage.removeItem('token')
  localStorage.removeItem('user')
}

// หน้าแรกของแต่ละบทบาท
export function homePath(role) {
  if (role === 'admin') return '/admin'
  if (role === 'committee') return '/committee'
  if (role === 'evaluatee') return '/evaluatee'
  return '/login'
}
