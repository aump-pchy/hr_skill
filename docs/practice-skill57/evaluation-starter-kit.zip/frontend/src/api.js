// [ไฟล์ร่วม] axios ตัวเดียวของทั้งระบบ แนบ token ให้อัตโนมัติ
// วิธีใช้:  import api, { errorMessage } from '../api'
//          const res = await api.get('/users', { params: { role: 'evaluatee' } })
//          rows.value = res.data.data
import axios from 'axios'
import { getToken, logout } from './auth'

const API_URL = import.meta.env.VITE_API_URL

const api = axios.create({ baseURL: `${API_URL}/api` })

api.interceptors.request.use((config) => {
  const token = getToken()
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// token หมดอายุ -> กลับไปหน้า login
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && !err.config.url.includes('/auth/login')) {
      logout()
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// ข้อความ error จาก API เอาไปแสดงบนหน้าจอได้ทันที
export function errorMessage(err) {
  return err.response?.data?.message || 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้'
}

// ลิงก์ไฟล์ที่อัปโหลด เช่น <a :href="fileUrl(item.file_path)">
export function fileUrl(fileName) {
  return `${API_URL}/uploads/${fileName}`
}

export default api
