// [ไฟล์ร่วม] รับไฟล์อัปโหลด เก็บในโฟลเดอร์ uploads/
// router.post('/x', auth, upload.single('file'), async (req, res) => { req.file?.filename })
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const dir = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(dir, { recursive: true });

const storage = multer.diskStorage({
  destination: dir,
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname).toLowerCase()),
});

const allowed = ['.pdf', '.jpg', '.jpeg', '.png'];

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (req, file, cb) => {
    if (allowed.includes(path.extname(file.originalname).toLowerCase())) return cb(null, true);
    cb(new Error('รับเฉพาะไฟล์ PDF, JPG, PNG'));
  },
});

module.exports = upload;
