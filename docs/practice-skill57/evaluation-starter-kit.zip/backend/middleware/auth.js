// [ไฟล์ร่วม] ตรวจ token และบทบาท
// router.get('/', auth, allow('admin'), async (req, res) => { ... req.user.id ... })
const jwt = require('jsonwebtoken');
const { fail } = require('../utils/response');

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return fail(res, 401, 'กรุณาเข้าสู่ระบบ');
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET); // { id, role, full_name }
    next();
  } catch (e) {
    return fail(res, 401, 'Token ไม่ถูกต้องหรือหมดอายุ');
  }
}

function allow(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) return fail(res, 403, 'ไม่มีสิทธิ์เข้าถึง');
    next();
  };
}

module.exports = { auth, allow };
