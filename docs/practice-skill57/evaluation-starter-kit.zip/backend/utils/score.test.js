// ทดสอบฟังก์ชันเฉพาะจุด (เกณฑ์ 7.5) รันด้วย:  npm test
const test = require('node:test');
const assert = require('node:assert');
const { weightedScore, totalPercent, progressPercent } = require('./score');

test('สเกล 1-4: ได้ 3 จากน้ำหนัก 20 = 15', () => {
  assert.strictEqual(weightedScore('scale_4', 3, 20), 15);
});

test('มี/ไม่มี: มี (1) จากน้ำหนัก 10 = 10, ไม่มี (0) = 0', () => {
  assert.strictEqual(weightedScore('yes_no', 1, 10), 10);
  assert.strictEqual(weightedScore('yes_no', 0, 10), 0);
});

test('ยังไม่ให้คะแนน = 0', () => {
  assert.strictEqual(weightedScore('scale_4', null, 20), 0);
});

test('ร้อยละรวม: เต็มทุกข้อ = 100', () => {
  const items = [
    { eval_type: 'scale_4', score: 4, weight: 30 },
    { eval_type: 'yes_no', score: 1, weight: 20 },
  ];
  assert.strictEqual(totalPercent(items), 100);
});

test('ร้อยละที่บันทึก: 3 จาก 4 = 75', () => {
  assert.strictEqual(progressPercent(3, 4), 75);
});
