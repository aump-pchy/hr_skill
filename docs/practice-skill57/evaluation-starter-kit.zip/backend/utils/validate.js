// [ไฟล์ร่วม] ตรวจว่าส่งข้อมูลมาครบไหม คืนค่าข้อความผิดพลาด หรือ null ถ้าครบ
// const err = required(req.body, ['username', 'full_name']);
// if (err) return fail(res, 400, err);
function required(body, fields) {
  const missing = fields.filter((f) => body[f] === undefined || body[f] === null || String(body[f]).trim() === '');
  return missing.length ? `กรุณากรอก: ${missing.join(', ')}` : null;
}

module.exports = { required };
