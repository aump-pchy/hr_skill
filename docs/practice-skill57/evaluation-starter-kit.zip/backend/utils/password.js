// [ไฟล์ร่วม] เข้ารหัสรหัสผ่านด้วย crypto ที่ติดมากับ Node (ไม่ต้องติดตั้งเพิ่ม)
const crypto = require('crypto');

const DEFAULT_PASSWORD = '1234';

function hashPassword(plain) {
  const salt = crypto.randomBytes(8).toString('hex');
  const hash = crypto.scryptSync(String(plain), salt, 32).toString('hex');
  return `${salt}:${hash}`;
}

function checkPassword(plain, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  return crypto.scryptSync(String(plain), salt, 32).toString('hex') === hash;
}

module.exports = { hashPassword, checkPassword, DEFAULT_PASSWORD };
