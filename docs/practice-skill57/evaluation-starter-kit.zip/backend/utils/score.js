// [ไฟล์ร่วม] สูตรคะแนนที่ทั้งทีมใช้ตรงกัน
// yes_no : score 1 = มี, 0 = ไม่มี      -> score x weight
// scale_4: score 1-4                    -> score / 4 x weight
function weightedScore(evalType, score, weight) {
  if (score === null || score === undefined) return 0;
  const w = Number(weight);
  if (evalType === 'yes_no') return Number(score) * w;
  return (Number(score) / 4) * w;
}

// items = [{ eval_type, score, weight }, ...]  ->  ร้อยละ 0-100 ทศนิยม 2 ตำแหน่ง
function totalPercent(items) {
  const totalWeight = items.reduce((sum, i) => sum + Number(i.weight), 0);
  if (totalWeight === 0) return 0;
  const got = items.reduce((sum, i) => sum + weightedScore(i.eval_type, i.score, i.weight), 0);
  return Math.round((got / totalWeight) * 10000) / 100;
}

// ร้อยละที่บันทึกแล้ว เช่น progressPercent(3, 4) -> 75
function progressPercent(done, total) {
  if (!total) return 0;
  return Math.round((done / total) * 100);
}

module.exports = { weightedScore, totalPercent, progressPercent };
