// [ไฟล์ร่วม] ตอบกลับรูปแบบเดียวทั้งระบบ { status, message, data }
// ok(res, data)                      -> 200
// ok(res, data, 'เพิ่มสำเร็จ', 201)    -> 201
// fail(res, 404, 'ไม่พบข้อมูล')
function ok(res, data = null, message = 'สำเร็จ', code = 200) {
  return res.status(code).json({ status: 'success', message, data });
}

function fail(res, code, message) {
  return res.status(code).json({ status: 'error', message, data: null });
}

module.exports = { ok, fail };
