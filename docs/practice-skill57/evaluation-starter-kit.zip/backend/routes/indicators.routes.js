// [คนที่ 1 — งานบุคลากร] ตัวชี้วัด + รูปแบบการประเมิน (yes_no / scale_4)
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { required } = require('../utils/validate');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('admin'));

// ตัวอย่าง — GET /api/indicators?topic_id=1
router.get('/', async (req, res) => {
  try {
    if (!req.query.topic_id) return fail(res, 400, 'กรุณาระบุ topic_id');
    const [rows] = await db.query('SELECT * FROM indicators WHERE topic_id = ? ORDER BY id', [req.query.topic_id]);
    ok(res, rows);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// TODO A5/A6  POST   /      body: topic_id, name, detail, weight, eval_type, evidence_note
//             eval_type ต้องเป็น 'yes_no' หรือ 'scale_4' เท่านั้น -> ไม่ใช่ = 400
// TODO A5     PUT    /:id
// TODO A5     DELETE /:id

module.exports = router;
