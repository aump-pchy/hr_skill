// [คนที่ 1 — งานบุคลากร] จัดการผู้ใช้   ทุก endpoint ในไฟล์นี้: auth + allow('admin')
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { required } = require('../utils/validate');
const { hashPassword, DEFAULT_PASSWORD } = require('../utils/password');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('admin'));

// ตัวอย่างรูปแบบมาตรฐาน — GET /api/users?role=evaluatee
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, username, full_name, email, phone, position, role FROM users WHERE role = ? ORDER BY id',
      [req.query.role || 'evaluatee']
    );
    ok(res, rows);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// TODO A1/A2  POST   /           เพิ่มผู้ใช้ (รหัสเริ่มต้น DEFAULT_PASSWORD, must_change_password = 1) ตอบ 201
//             ตรวจ username ซ้ำ -> fail 400
// TODO A1/A2  PUT    /:id        แก้ไข  (affectedRows = 0 -> fail 404)
// TODO A1/A2  DELETE /:id        ลบ     (affectedRows = 0 -> fail 404)
// TODO A3     PUT    /:id/reset-password   รหัส = DEFAULT_PASSWORD, must_change_password = 1

module.exports = router;
