// [คนที่ 3 — ผู้รับการประเมิน]   ทุก endpoint: auth + allow('evaluatee')
// กฎสำคัญ: ใช้ req.user.id เสมอ ห้ามรับ evaluatee_id จาก body
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { required } = require('../utils/validate');
const upload = require('../middleware/upload');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('evaluatee'));

// helper ใช้ซ้ำ: หัวข้อที่เปิดอยู่วันนี้ (ไม่มี -> null)
async function openTopic() {
  const [rows] = await db.query(
    'SELECT * FROM topics WHERE CURDATE() BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1'
  );
  return rows[0] || null;
}

// ตัวอย่าง — PUT /api/evaluatee/profile   แก้ข้อมูลส่วนตัว (E2)
router.put('/profile', async (req, res) => {
  try {
    const err = required(req.body, ['full_name', 'email']);
    if (err) return fail(res, 400, err);
    const { full_name, email, phone, position } = req.body;
    await db.query('UPDATE users SET full_name = ?, email = ?, phone = ?, position = ? WHERE id = ?', [
      full_name,
      email,
      phone || null,
      position || null,
      req.user.id,
    ]);
    ok(res, null, 'บันทึกข้อมูลส่วนตัวสำเร็จ');
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// TODO E3/E7  GET /indicators
//          openTopic() ไม่มี -> 404 'ยังไม่เปิดการประเมิน' | ตัวชี้วัดของหัวข้อ + self_score + evidences[]
// TODO E6     PUT /self-scores/:indicatorId   body: score
//          ตรวจช่วงคะแนนตาม eval_type (yes_no: 0/1, scale_4: 1-4) | INSERT ... ON DUPLICATE KEY UPDATE
// TODO E4/E5  POST /evidences   upload.single('file')   form-data: indicator_id, detail, url
//          ต้องมี detail | file_path = req.file ? req.file.filename : null | ตอบ 201
// TODO E4     DELETE /evidences/:id   (ลบได้เฉพาะของตัวเอง: AND evaluatee_id = req.user.id)
// TODO E9     GET /comments   ชื่อกรรมการ, บทบาท, overall_comment, status จาก assignments ของตัวเอง

module.exports = router;
