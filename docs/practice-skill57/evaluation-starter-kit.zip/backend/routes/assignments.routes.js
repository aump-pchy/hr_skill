// [คนที่ 1 — งานบุคลากร] มอบหมายกรรมการ + บทบาท (chair / member) + ติดตามสถานะ
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { required } = require('../utils/validate');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('admin'));

// ตัวอย่าง (ใช้ JOIN) — GET /api/assignments?topic_id=1   ได้ชื่อทั้งสองฝั่ง + สถานะ (A9)
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT a.*, e.full_name AS evaluatee_name, c.full_name AS committee_name
       FROM assignments a
       JOIN users e ON e.id = a.evaluatee_id
       JOIN users c ON c.id = a.committee_id
       WHERE a.topic_id = ?
       ORDER BY e.full_name, a.committee_role`,
      [req.query.topic_id]
    );
    ok(res, rows);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// TODO A7  POST   /      body: topic_id, evaluatee_id, committee_id, committee_role
//          มอบหมายซ้ำคู่เดิม -> MySQL error ER_DUP_ENTRY -> fail 400 'มอบหมายซ้ำ'
// TODO A8  PUT    /:id   body: committee_role
// TODO A7  DELETE /:id

module.exports = router;
