// [คนที่ 1 — งานบุคลากร] หัวข้อการประเมิน + ช่วงเปิด-ปิด
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { required } = require('../utils/validate');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('admin'));

// ตัวอย่าง — GET /api/topics   (is_open = 1 ถ้าวันนี้อยู่ในช่วงเปิด)
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT *, (CURDATE() BETWEEN start_date AND end_date) AS is_open
       FROM topics ORDER BY id DESC`
    );
    ok(res, rows);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// TODO A4  POST   /       body: title, description, start_date, end_date  (start_date > end_date -> 400)
// TODO A4  PUT    /:id
// TODO A4  DELETE /:id    (ตัวชี้วัดในหัวข้อถูกลบตามด้วย ON DELETE CASCADE)

module.exports = router;
