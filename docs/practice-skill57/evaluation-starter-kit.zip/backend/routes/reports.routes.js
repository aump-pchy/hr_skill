// [คนที่ 1 — งานบุคลากร] รายงานและ Dashboard
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { totalPercent, progressPercent } = require('../utils/score');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('admin'));

// ตัวอย่าง — GET /api/reports/dashboard   ตัวเลขสรุป (A13)
router.get('/dashboard', async (req, res) => {
  try {
    const [[counts]] = await db.query(
      `SELECT
         (SELECT COUNT(*) FROM users WHERE role = 'evaluatee') AS evaluatees,
         (SELECT COUNT(*) FROM users WHERE role = 'committee') AS committees,
         (SELECT COUNT(*) FROM assignments WHERE status = 'confirmed') AS confirmed,
         (SELECT COUNT(*) FROM assignments) AS assignments`
    );
    ok(res, counts);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// TODO A13  เพิ่มค่าเฉลี่ยคะแนน (ร้อยละ) ของผู้ที่กรรมการยืนยันแล้ว ใน /dashboard
// TODO A10  GET /progress?topic_id=   ต่อผู้รับการประเมิน 1 คน: จำนวนตัวชี้วัดที่มี self_scores / ทั้งหมด -> progressPercent
// TODO A11/A12  GET /evaluatees/:id?topic_id=
//          ตัวชี้วัดทุกตัว + คะแนนตนเอง + คะแนนของกรรมการแต่ละคน + totalPercent ของแต่ละกรรมการ + ความเห็น

module.exports = router;
