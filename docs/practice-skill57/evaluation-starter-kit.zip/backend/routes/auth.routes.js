// [ไฟล์ร่วม] Login / ข้อมูลตัวเอง / เปลี่ยนรหัสผ่าน — เขียนเสร็จแล้ว ใช้ได้ทุกบทบาท
const router = require('express').Router();
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const { required } = require('../utils/validate');
const { hashPassword, checkPassword } = require('../utils/password');
const { auth } = require('../middleware/auth');

// POST /api/auth/login   body: { username, password }
router.post('/login', async (req, res) => {
  try {
    const err = required(req.body, ['username', 'password']);
    if (err) return fail(res, 400, err);

    const [rows] = await db.query('SELECT * FROM users WHERE username = ?', [req.body.username]);
    const user = rows[0];
    if (!user || !checkPassword(req.body.password, user.password_hash)) {
      return fail(res, 401, 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, full_name: user.full_name },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES || '8h' }
    );
    delete user.password_hash;
    ok(res, { token, user }, 'เข้าสู่ระบบสำเร็จ');
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// GET /api/auth/me
router.get('/me', auth, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id, username, full_name, email, phone, position, role, must_change_password FROM users WHERE id = ?',
      [req.user.id]
    );
    if (!rows.length) return fail(res, 404, 'ไม่พบผู้ใช้');
    ok(res, rows[0]);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// PUT /api/auth/change-password   body: { old_password, new_password }
router.put('/change-password', auth, async (req, res) => {
  try {
    const err = required(req.body, ['old_password', 'new_password']);
    if (err) return fail(res, 400, err);
    if (String(req.body.new_password).length < 6) return fail(res, 400, 'รหัสผ่านใหม่ต้องยาวอย่างน้อย 6 ตัวอักษร');

    const [rows] = await db.query('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    if (!rows.length) return fail(res, 404, 'ไม่พบผู้ใช้');
    if (!checkPassword(req.body.old_password, rows[0].password_hash)) return fail(res, 400, 'รหัสผ่านเดิมไม่ถูกต้อง');

    await db.query('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?', [
      hashPassword(req.body.new_password),
      req.user.id,
    ]);
    ok(res, null, 'เปลี่ยนรหัสผ่านสำเร็จ');
  } catch (e) {
    fail(res, 500, e.message);
  }
});

module.exports = router;
