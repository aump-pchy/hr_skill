// [คนที่ 2 — กรรมการ]   ทุก endpoint: auth + allow('committee')
// กฎสำคัญ: กรรมการเห็นได้เฉพาะ assignment ที่ committee_id = req.user.id
const router = require('express').Router();
const db = require('../config/db');
const { ok, fail } = require('../utils/response');
const upload = require('../middleware/upload');
const { totalPercent } = require('../utils/score');
const { auth, allow } = require('../middleware/auth');

router.use(auth, allow('committee'));

// ตัวอย่าง — GET /api/committee/assignments   รายชื่อที่ต้องประเมิน (C1)
router.get('/assignments', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT a.id, a.status, a.committee_role, u.full_name AS evaluatee_name, u.position, t.title AS topic_title
       FROM assignments a
       JOIN users u ON u.id = a.evaluatee_id
       JOIN topics t ON t.id = a.topic_id
       WHERE a.committee_id = ?
       ORDER BY a.id`,
      [req.user.id]
    );
    ok(res, rows);
  } catch (e) {
    fail(res, 500, e.message);
  }
});

// helper ใช้ซ้ำ: ดึง assignment ของ "ตัวเอง" ถ้าไม่ใช่ของตัวเอง -> null
async function myAssignment(id, userId) {
  const [rows] = await db.query('SELECT * FROM assignments WHERE id = ? AND committee_id = ?', [id, userId]);
  return rows[0] || null;
}

// TODO C2  GET /assignments/:id
//          myAssignment ไม่เจอ -> 404 | ส่งกลับ: ข้อมูลผู้รับการประเมิน, ตัวชี้วัดของหัวข้อ
//          แต่ละตัวมี self_score, evidences[], my_score  + overall_comment, signature_path, status
// TODO C3/C4/C5  PUT /assignments/:id/scores   body: { scores: [{indicator_id, score}], overall_comment }
//          status = 'confirmed' -> 403 | INSERT ... ON DUPLICATE KEY UPDATE | status = 'draft'
// TODO C6  ใส่ total_percent (totalPercent) ในผลของ GET /assignments/:id
// TODO C7  POST /assignments/:id/signature   upload.single('file') -> signature_path
// TODO C8  PUT  /assignments/:id/confirm   ต้องให้คะแนนครบทุกตัวชี้วัด + มีลายเซ็น ไม่งั้น 400
//          สำเร็จ: status = 'confirmed', confirmed_at = NOW()

module.exports = router;
