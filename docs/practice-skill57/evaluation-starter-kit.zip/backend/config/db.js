// [ไฟล์ร่วม] เชื่อมฐานข้อมูลด้วย pool ค่าทั้งหมดอ่านจาก .env
// วิธีใช้:  const db = require('../config/db');
//          const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [id]);
const mysql = require('mysql2/promise');

const db = mysql.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
  dateStrings: true, // วันที่ออกมาเป็น '2026-11-16' ไม่เพี้ยน timezone
});

module.exports = db;
