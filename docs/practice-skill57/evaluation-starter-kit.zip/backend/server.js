// [ไฟล์ร่วม] จุดเริ่มของเซิร์ฟเวอร์ — ทุก route ลงทะเบียนไว้ครบแล้ว ไม่ต้องแก้ไฟล์นี้
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { fail } = require('./utils/response');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ---- ร่วมกัน ----
app.use('/api/auth', require('./routes/auth.routes'));
// ---- คนที่ 1: งานบุคลากร ----
app.use('/api/users', require('./routes/users.routes'));
app.use('/api/topics', require('./routes/topics.routes'));
app.use('/api/indicators', require('./routes/indicators.routes'));
app.use('/api/assignments', require('./routes/assignments.routes'));
app.use('/api/reports', require('./routes/reports.routes'));
// ---- คนที่ 2: กรรมการ ----
app.use('/api/committee', require('./routes/committee.routes'));
// ---- คนที่ 3: ผู้รับการประเมิน ----
app.use('/api/evaluatee', require('./routes/evaluatee.routes'));

// ไม่พบ path
app.use((req, res) => fail(res, 404, 'ไม่พบ API นี้'));
// error ที่หลุดมา เช่น ไฟล์ใหญ่เกิน / ชนิดไฟล์ผิด จาก multer
app.use((err, req, res, next) => {
  console.error(err);
  fail(res, err.status || 400, err.message || 'เกิดข้อผิดพลาด');
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API พร้อมที่ http://localhost:${port}`));
