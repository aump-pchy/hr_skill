# ชุดเริ่มต้น ระบบประเมินบุคลากร (รายการที่ 57)

## ติดตั้งครั้งแรก (ทุกคนทำเหมือนกัน)
1. ฐานข้อมูล: เปิด HeidiSQL รัน `database/schema.sql` แล้วรัน `database/seed.sql`
2. Back-end:
   ```
   cd backend
   copy .env.example .env      (แก้ DB_USER / DB_PASSWORD ให้ตรงเครื่อง)
   npm install
   npm run dev                 -> http://localhost:3000
   npm test                    -> ทดสอบสูตรคะแนน
   ```
3. Front-end:
   ```
   cd frontend
   copy .env.example .env
   npm install
   npm run dev                 -> http://localhost:5173
   ```

บัญชีทดสอบ (รหัส 1234 ทุกบัญชี): admin · eva1 · eva2 (ถูกบังคับเปลี่ยนรหัส) · com1 (ประธาน) · com2 (ถูกบังคับเปลี่ยนรหัส)
รีเซ็ตข้อมูลเมื่อไหร่ก็ได้: รัน `seed.sql` ซ้ำ

## ไฟล์ของใคร
| ใคร | Back-end (routes/) | Front-end (src/views/) |
|---|---|---|
| ร่วม (ห้ามแก้) | server.js, config/, utils/, middleware/, auth.routes.js | api.js, auth.js, router/, App.vue, LoginView.vue |
| คนที่ 1 งานบุคลากร | users, topics, indicators, assignments, reports | admin/ |
| คนที่ 2 กรรมการ | committee.routes.js | committee/ |
| คนที่ 3 ผู้รับการประเมิน | evaluatee.routes.js | evaluatee/, ChangePasswordView.vue |

## รวมระบบ (ไม่มี Git)
คัดลอกเฉพาะไฟล์ของตัวเองไปทับในเครื่องหลัก ไฟล์ร่วมไม่มีใครแก้ จึงไม่ชนกัน
